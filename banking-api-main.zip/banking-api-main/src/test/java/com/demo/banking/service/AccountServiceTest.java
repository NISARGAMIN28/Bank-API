package com.demo.banking.service;

import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class AccountServiceTest {
}
