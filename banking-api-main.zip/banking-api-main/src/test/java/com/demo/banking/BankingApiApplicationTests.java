package com.demo.banking;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BankingApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
