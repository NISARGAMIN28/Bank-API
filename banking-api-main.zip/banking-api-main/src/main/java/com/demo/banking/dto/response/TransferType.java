package com.demo.banking.dto.response;

public enum TransferType {
    CREDIT,
    DEBIT
}
