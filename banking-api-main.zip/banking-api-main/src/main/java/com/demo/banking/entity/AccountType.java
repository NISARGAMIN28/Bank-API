package com.demo.banking.entity;

public enum AccountType {
    USD,
    EUR
}
