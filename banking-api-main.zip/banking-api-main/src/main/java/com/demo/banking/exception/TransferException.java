package com.demo.banking.exception;


public class TransferException extends Exception {
    public TransferException(String message) {
        super(message);
    }
}
